# Movie recomendation system using KMeans clustering

## Data Collection

I used imdb movies and scraped them to collect data. Dataset of 4975 unique movies were collected and clustered. To scrape execute scraper.py

    python scraper.py

## Preprocessing

Then collected data are clustered using pre_processing.py

    python pre_processing.py

## Testing the model

Then clusters are used main.py file

    python main.py